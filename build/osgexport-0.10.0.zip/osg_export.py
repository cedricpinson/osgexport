def main():
    import sys
    import os
    import bpy

    sys.path.insert(0, "./")
    BlenderExporterDir = os.getenv("BlenderExporter", os.path.join(bpy.context.user_preferences.filepaths.script_directory,"blenderExporter"))
    print("BlenderExporter directory ", BlenderExporterDir)
    sys.path.append(BlenderExporterDir)


    import sys       # to get command line args
    import argparse  # to parse options for us and print a nice help message

    # get the args passed to blender after "--", all of which are ignored by
    # blender so scripts may receive their own arguments
    argv = sys.argv

    if "--" not in argv:
        argv = []  # as if no args are passed
    else:
        argv = argv[argv.index("--") + 1:]  # get all args after "--"

    # When --help or no args are given, print this help
    usage_text = \
    "Run blender in background mode with this script:"
    "  blender --background --python " + __file__ + " -- [options]"

    parser = argparse.ArgumentParser(description=usage_text)

    # Example utility, add some text and renders or saves it (with options)
    # Possible types are: string, int, long, choice, float and complex.
    parser.add_argument("-s", "--save", dest="save_path", metavar='FILE|PATH', help="Save the generated file to the specified path")
    parser.add_argument("-a", "--enable-animation", dest="enable_animation", action="store_const", const=True, default=False, help="Enable saving of animations")
    parser.add_argument("-m", "--apply-modifiers", dest="apply_modifiers", action="store_const", const=True, default=False, help="Apply modifiers before exporting")

    args = parser.parse_args(argv)  # In this example we wont use the args

    import osg
    from osg import osgconf
    config = osgconf.Config()
    config.filename = args.save_path
    config.export_anim = args.enable_animation,
    config.apply_modifiers = args.apply_modifiers

    config.scene = bpy.context.scene
    osg.OpenSceneGraphExport(config)
    

if __name__ == "__main__":
    main()
